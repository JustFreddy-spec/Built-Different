import { useEffect } from "react";

export default function Home() {
  useEffect(() => {
    if (typeof window !== "undefined" && window.paypal) {
      window.paypal.Buttons({
        style: {
          layout: "vertical",
          color: "gold",
          shape: "rect",
          label: "paypal",
        },
        createOrder: function (data, actions) {
          return actions.order.create({
            purchase_units: [
              {
                amount: {
                  value: "40.00",
                },
              },
            ],
          });
        },
        onApprove: function (data, actions) {
          return actions.order.capture().then(function (details) {
            alert("Transaction completed by " + details.payer.name.given_name);
          });
        },
      }).render("#paypal-button-container");
    }
  }, []);

  return (
    <div className="min-h-screen bg-black text-white">
      <header className="py-6 px-4 border-b border-gray-800 flex justify-between items-center">
        <h1 className="text-2xl font-bold">BUILT DIFFERENT</h1>
        <nav className="space-x-4">
          <a href="#buy" className="hover:text-gray-400">Shop</a>
          <a href="#story" className="hover:text-gray-400">Story</a>
          <a href="#contact" className="hover:text-gray-400">Contact</a>
        </nav>
      </header>

      <main className="text-center py-20 px-6">
        <h2 className="text-5xl font-bold mb-4">Walk Your Own Way</h2>
        <p className="text-gray-400 max-w-xl mx-auto mb-6">
          Not everyone is meant to follow the crowd. Our premium hoodie is for those who lead.
        </p>
        <a href="#buy" className="bg-white text-black px-6 py-3 rounded-full font-bold hover:bg-gray-200">
          Shop Now – $40 (30% OFF)
        </a>
      </main>

      <section id="buy" className="py-20 px-6 grid md:grid-cols-2 gap-12 items-center">
        <img src="/hoodie.jpg" alt="Built Different Hoodie" className="rounded-xl shadow-xl" />
        <div>
          <h3 className="text-3xl font-semibold mb-4">BUILT DIFFERENT Hoodie</h3>
          <p className="text-gray-400 mb-6">
            Premium fit. Limited drop. Made for those who don’t follow trends — they set them.
          </p>
          <ul className="list-disc list-inside text-gray-300 mb-4">
            <li>High-quality cotton/poly blend</li>
            <li>Embroidered front branding</li>
            <li>Ships worldwide</li>
          </ul>
          <div id="paypal-button-container" className="mt-6"></div>
        </div>
      </section>

      <section id="story" className="bg-gray-900 text-center py-20 px-6">
        <h4 className="text-2xl font-bold mb-4">Why Built Different?</h4>
        <p className="text-gray-400 max-w-2xl mx-auto">
          This brand represents ambition and self-mastery. It’s for creators, leaders, and visionaries who choose to rise by design.
        </p>
      </section>

      <footer className="text-center text-gray-500 text-sm py-6 border-t border-gray-800">
        &copy; 2025 Built Different. All rights reserved.
      </footer>

      <script src="https://www.paypal.com/sdk/js?client-id=YOUR_CLIENT_ID&currency=USD"></script>
    </div>
  );
}